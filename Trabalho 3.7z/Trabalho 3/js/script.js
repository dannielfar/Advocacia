window.onload = function() {
  const abrirBtn1 = document.querySelector("#abrir1");
  abrirBtn1.addEventListener("click", abrirModal1);

  const fecharBtn1 = document.querySelector("#myModal1 .close");
  fecharBtn1.addEventListener("click", fecharModal1);

  const abrirBtn2 = document.querySelector("#abrir2");
  abrirBtn2.addEventListener("click", abrirModal2);

  const fecharBtn2 = document.querySelector("#myModal2 .close");
  fecharBtn2.addEventListener("click", fecharModal2);

  window.addEventListener("click", function(event) {
    if (event.target === document.getElementById("myModal1")) {
      fecharModal1();
    } else if (event.target === document.getElementById("myModal2")) {
      fecharModal2();
    }
  });
};

function abrirModal1() {
  const modal1 = document.getElementById("myModal1");
  modal1.style.display = "block";
}

function fecharModal1() {
  const modal1 = document.getElementById("myModal1");
  modal1.style.display = "none";
}

function abrirModal2() {
  const modal2 = document.getElementById("myModal2");
  modal2.style.display = "block";
}

function fecharModal2() {
  const modal2 = document.getElementById("myModal2");
  modal2.style.display = "none";
}
